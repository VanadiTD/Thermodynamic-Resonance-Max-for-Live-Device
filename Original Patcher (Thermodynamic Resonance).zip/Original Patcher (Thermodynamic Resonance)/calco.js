function msg_float(v) {
    var result;
    
    if (v <= 194) {
        result = 0;  
    } else {
        result = 0.1;
    }
    
    outlet(0, result);
}